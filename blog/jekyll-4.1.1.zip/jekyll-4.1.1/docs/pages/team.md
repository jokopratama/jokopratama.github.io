---
layout: page
title: The Jekyll Team
permalink: /team/
---

## Core Team

_The Jekyll Core Team's responsibility is to ensure the development and
community around the Jekyll ecosystem thrive._

* Ashwin (@ashmaroli)
* Frank (@DirtyF)
* Matt (@mattr-)

## Emeritus Core Team Members

_Emeritus Core Team Members were once members of Jekyll's Core Team._

* Alfred (@alfredxing)
* Nick (@qrush)
* Parker (@parkr)
* Tom (@mojombo)
