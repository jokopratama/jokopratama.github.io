﻿---
layout: post
title:  "UTF8CRLFandBOM"
date:   2017-04-05 16:16:01 -0800
categories: bom
---
This file was created with CR/LFs, and encoded as UTF8 with a BOM

You’ll find this post in your `_posts` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `bundle exec jekyll serve`, which launches a web server and auto-regenerates your site when a file is updated.

To add new posts, simply add a file in the `_posts` directory that follows the convention `YYYY-MM-DD-name-of-post.ext` and includes the necessary front matter. Take a look at the source for this post to get an idea about how it works.
